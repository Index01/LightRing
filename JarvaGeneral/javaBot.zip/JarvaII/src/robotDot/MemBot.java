/**
 * 
 */
package robotDot;

/**
 * @author Index
 *
 */
public class MemBot extends Robot {

	/**
	 * 
	 */
	public MemBot() {
		// TODO Auto-generated constructor stub
	}
	
	void move(){
		
	}
	
	void currentPos(int x, int y){
		
	}
	
	void direction(int z){
		
	}
	

}
