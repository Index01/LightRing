/**
 * 
 */
package robotDot;

/**
 * @author Index
 *
 */

import java.awt.*;
//import java.swig.*;

import javax.swing.JFrame;

public class Render { 

	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Canvas mainCan = new Canvas();
		JFrame mainFrame = new JFrame();
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		mainCan.setSize(820, 620);
		mainCan.setBackground(Color.black);

		
//	    mainFrame.setLayout(new FlowLayout);
		mainFrame.add(mainCan);
		mainFrame.setSize(820, 620);
		mainFrame.setVisible(true);
		
		

	}

}

//Canvas C1 = new Canvas();
//C1.setSize(120,120);
//C1.setBackground(Color.white);
//
//Frame F1 = new Frame();
//F1.add(C1);
//F1.setLayout(new FlowLayout());
//F1.setSize(250,250);
//F1.setVisible(true);