/**
 * 
 */
package robotDot;

/**
 * @author Index
 *
 */
public class RandomRob extends Robot {

	/**
	 * 
	 */
	public RandomRob() {
		// TODO Auto-generated constructor stub
	}
	
	
	void move(){
		
	}
	
	void currentPos(int x, int y){
		
	}
	
	void direction(int z){
		
	}


}
