/**
 * 
 */
package robotDot;

/**
 * @author Index
 *
 */
public abstract class Robot {
	
	abstract void move();
	abstract void currentPos(int x, int y);
	abstract void direction(int z);

}
