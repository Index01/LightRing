/**
 * 
 */
package robotDot;

import java.util.*;
import java.math.*;

/**
 * @author Index
 */
public class Maze {
	int[][] layoutConf;
	int difficulty;
	Random rand = new Random();

	public Maze(int diff) {
		difficulty = diff;
		// Maze accepts an int difficulty and an object type robot
	}

	/* create array =new array[10][10] */
	/* difficulty level will be verified and parsed for a usable value */

	// public enum Coordinate(int xPos, int yPos){
	// public hasNeighbor();
	//
	// public move();
	//
	//
	// }

	public class BlankMaze {
		public BlankMaze() {
			int curX;
			int curY;
			int width = difficulty;
			int max;

			if (difficulty != 0) {
				width = difficulty * 10;
			}

			max = width - 1;
			int startNum = rand.nextInt(max);
			int endNum = rand.nextInt(max);
			layoutConf = new int[width][width];

			for (int i = 0; i < layoutConf.length; i++) {
				for (int j = 0; j < layoutConf.length; j++) {
					layoutConf[i][j] = 1;
					layoutConf[i][0] = 2;
					layoutConf[i][width - 1] = 2;
					layoutConf[0][j] = 2;
					layoutConf[width - 1][j] = 2;
					curX = i;
					curY = j;
				}
				/*
				 * generate a �start� and �end� point which is nearest a 0 val
				 * in the arrays.
				 */
				layoutConf[0][startNum] = 3;
				layoutConf[endNum][max] = 3;
			}

		}

		public void disp() {
			for (int o = 0; o < layoutConf.length; o++) {
				for (int i = 0; i < layoutConf.length; i++) {
					System.out.print(layoutConf[o][i]);
				}
				System.out.println();
			}
		}

		public int getVals() {
			int val = 0;
			for (int i = 0; i < layoutConf.length; i++) {
				for (int ii = 0; ii < layoutConf.length; ii++) {
					val = layoutConf[i][ii];
				}
			}
			return val;
		}

		public void setVals(int x, int y, int val) {
			layoutConf[y][x] = val;
		}

		public void nextPosition() {
			int start = 0;
			int position = 0;
			int y = 0;
			int yClean = 0;
			for (int z = 0; z < layoutConf.length; z++) {
				if (layoutConf[0][z] == 3) {
					layoutConf[1][z] = 0;
					start = z;
				}
			}

			outer:

			for (int x = 1; x < layoutConf.length; x++) {
				// inner:
				// for(int y=start; y<layoutConf.length;y++){
				inner:
				if (x == 1) {
					y = start;
				} 
				else {
					yClean = yClean + 1;
					System.out.println("clean" + yClean + "y" + y);

					if (yClean<layoutConf.length && layoutConf[x][yClean] == 1) {
						int choseDir = rand.nextInt(3);
						switch (choseDir) {
						case 1:
							if (yClean - 3 != 2 && yClean -3 > 0) {
								layoutConf[x][yClean - 1] = 0;
								layoutConf[x][yClean - 2] = 0;
								layoutConf[x][yClean - 3] = 0;
								yClean = yClean - 2;
								// break inner;
							}
							else {
								layoutConf[x][yClean - 1] = 0;
							}
						case 2:
							if (x + 1 != 2) {
								layoutConf[x + 1][yClean] = 0;
								layoutConf[x + 2][yClean] = 0;
								layoutConf[x + 3][yClean] = 0;
								// break inner;
								// x+=x;
							}
						case 3:
							if (yClean + 3 != 2 && yClean +3 < layoutConf.length) {
								layoutConf[x][yClean + 1] = 0;
								layoutConf[x][yClean + 2] = 0;
								layoutConf[x][yClean + 3] = 0;
								// break inner;
								yClean = yClean + 2;
							}
							else {
								layoutConf[x][yClean + 1] = 0;
							}

						}
					}
					else{
						break inner;	
					}
					
				}
			}
		}
	}

	public static void main(String[] args) {
		Maze myMaze = new Maze(2);
		Maze.BlankMaze tempMaze = myMaze.new BlankMaze();
		tempMaze.nextPosition();
		tempMaze.disp();
		// System.out.println(tempMaze.getVals());
	}

	/* randomly generate 1 or 0 and fill the arrays */

	// the number of 1's (�walls�) found in the array will be determined by the
	// difficulty passed to the maze

	/* i'm not sure how I will prevent the maze from being unsolvable */

	/*
	 * method to pull out each value and allow it to be rendered, 1=wall, 0=
	 * blank
	 */

	/* implement some generic error handling */

	/*
	 * maze will also implement the render interface allowing it to display
	 * itself
	 */

	/*
	 * run() method will place the �robot� at the starting point and move it
	 * towards the �end�
	 */

}
