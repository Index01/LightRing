/**
 * 
 */
package robotDot;

/**
 * @author Index
 *
 */
public class RightyRobo extends Robot {

	/**
	 * 
	 */
	public RightyRobo() {
		// TODO Auto-generated constructor stub
	}
	
	void move(){
		
	}
	
	void currentPos(int x, int y){
		
	}
	
	void direction(int z){
		
	}

}
